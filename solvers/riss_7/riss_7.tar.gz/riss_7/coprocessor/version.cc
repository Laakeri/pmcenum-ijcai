/*
 * This file was created automatically. Do not change it.
 * If you want to distribute the source code without
 * git, make sure you include this file in your bundle.
 */
#include "coprocessor/version.h"

const char* Coprocessor::gitSHA1            = "cf1a66e";
const char* Coprocessor::gitDate            = "Sun May 28 20:45:58 2017";
const char* Coprocessor::coprocessorVersion = "7.0.0";
const char* Coprocessor::signature          = "coprocessor 7.0.0 build cf1a66e";
