/*
 * This file was created automatically. Do not change it.
 * If you want to distribute the source code without
 * git, make sure you include this file in your bundle.
 */
#include "riss/utils/version.h"

const char* Riss::gitSHA1         = "cf1a66e";
const char* Riss::gitDate         = "Sun May 28 20:45:58 2017";
const char* Riss::solverVersion   = "7.0.0";
const char* Riss::signature       = "riss 7.0.0 build cf1a66e";
